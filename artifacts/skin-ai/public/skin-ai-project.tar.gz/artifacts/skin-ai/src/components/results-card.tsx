import { motion } from "framer-motion";
import { CheckCircle2, ChevronRight, ActivitySquare, Cpu, Search } from "lucide-react";
import { PredictionResult } from "@workspace/api-client-react";
import { SeverityBadge } from "./ui/severity-badge";
import { formatConfidence } from "@/lib/utils";

interface ResultsCardProps {
  result: PredictionResult;
  onReset: () => void;
}

export function ResultsCard({ result, onReset }: ResultsCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-200/60 overflow-hidden"
    >
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 p-8 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/20 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/2" />
        
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-4">
            <SeverityBadge severity={result.severity} />
            <span className="text-slate-400 text-sm flex items-center gap-1">
              <Search className="w-3.5 h-3.5" /> 
              Analysis Complete
            </span>
          </div>
          
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-6 text-teal-400">
            {result.disease}
          </h2>
          
          <div className="space-y-2 max-w-md">
            <div className="flex justify-between text-sm font-medium">
              <span className="text-slate-300">AI Confidence Score</span>
              <span className="text-primary-foreground">{formatConfidence(result.confidence)}</span>
            </div>
            <div className="h-3 w-full bg-slate-700 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${result.confidence * 100}%` }}
                transition={{ duration: 1, delay: 0.2, ease: "easeOut" }}
                className="h-full bg-gradient-to-r from-primary to-teal-300"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="space-y-8">
          <section>
            <div className="flex items-center gap-2 text-primary font-bold mb-3">
              <ActivitySquare className="w-5 h-5" />
              <h3>Clinical Description</h3>
            </div>
            <p className="text-slate-600 leading-relaxed">
              {result.description}
            </p>
          </section>

          <section>
            <div className="flex items-center gap-2 text-primary font-bold mb-4">
              <CheckCircle2 className="w-5 h-5" />
              <h3>Recommendations</h3>
            </div>
            <ul className="space-y-3">
              {result.recommendations.map((rec, i) => (
                <motion.li 
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + (i * 0.1) }}
                  className="flex items-start gap-3 bg-slate-50 p-3 rounded-xl border border-slate-100"
                >
                  <ChevronRight className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                  <span className="text-slate-700 text-sm">{rec}</span>
                </motion.li>
              ))}
            </ul>
          </section>
        </div>

        <div className="space-y-8">
          <section className="bg-slate-50 rounded-2xl p-6 border border-slate-200/60">
            <h3 className="font-bold text-foreground mb-4">Differential Diagnoses</h3>
            <div className="space-y-4">
              {result.differentialDiagnoses.map((diag, i) => (
                <div key={i} className="space-y-1.5">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-700 font-medium">{diag.disease}</span>
                    <span className="text-slate-500 font-mono">{formatConfidence(diag.confidence)}</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-slate-400 rounded-full" 
                      style={{ width: `${diag.confidence * 100}%` }} 
                    />
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section>
            <div className="flex items-center gap-2 text-slate-500 font-bold mb-3 text-sm uppercase tracking-wider">
              <Cpu className="w-4 h-4" />
              <h3>Pipeline Data</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {result.preprocessingSteps.map((step, i) => (
                <span key={i} className="px-2.5 py-1 bg-slate-100 text-slate-600 text-xs font-mono rounded-md border border-slate-200">
                  {step}
                </span>
              ))}
            </div>
          </section>
        </div>
      </div>

      <div className="p-6 bg-slate-50 border-t border-slate-100 text-center">
        <button
          onClick={onReset}
          className="px-8 py-3 rounded-xl font-semibold bg-white text-slate-700 border-2 border-slate-200 hover:border-primary hover:text-primary shadow-sm hover:shadow-md transition-all duration-200 active:scale-95"
        >
          Analyze Another Image
        </button>
      </div>
    </motion.div>
  );
}
